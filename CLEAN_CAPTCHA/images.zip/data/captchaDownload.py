import base64
import json

for i in range(20):
    with open('captcha' + str(i) + '.json') as data_file:
        json_file = json.load(data_file)

        for pic in json_file['images']:
            name = pic['name']
            fh = open(name+ ".png", "wb")
            fh.write(base64.decodestring(pic['jpg_base64']))
            fh.close()
# import urllib
# import json
# import cv2
# import numpy as np
# max = 1000
# link = "https://captcha.delorean.codes/u/likeaj6/challenge"
# f = urllib.urlopen(link)
# myfile = f.read()
# for i in range(0, max):
#     # print(i)
#     # a = open("names/blah" + str(i) + ".txt", "wb")
#     img_data = json.loads(myfile)[u'images'][i][u'jpg_base64']
#     #a.write(json.loads(myfile)[u'images'][i][u'name'])
#     #a.close()
#     fh = open(json.loads(myfile)[u'images'][i][u'name'] + ".png", "wb")
#     fh.write(img_data.decode('base64'))
#     fh.close()
#
# f.close()
